import React, { useState } from "react";

// Define types
type IndicatorType = "Critic" | "Non-Critic";
type CategorieType = "Comunicare" | "Procedura" | "Atitudine";
type NotaType = "1-9" | "1-5" | "0/0.5/1";

type Item = {
  tipIndicator: IndicatorType;
  categorie: CategorieType;
  descriere: string;
  metodologie: string;
  tipNota: NotaType;
  pondereCategorie: number;
  pondereNota: number;
  materialeTraining: string;
  temeTraining: string;
};

const defaultItem: Item = {
  tipIndicator: "Critic",
  categorie: "Comunicare",
  descriere: "",
  metodologie: "",
  tipNota: "1-9",
  pondereCategorie: 0,
  pondereNota: 0,
  materialeTraining: "",
  temeTraining: "",
};

const CATEGORII: CategorieType[] = ["Comunicare", "Procedura", "Atitudine"];
const TIPURI: IndicatorType[] = ["Critic", "Non-Critic"];

const FormularEvaluareBuilder = ({
  onBack,
  onSave,
}: {
  onBack?: () => void;
  onSave?: (items: Item[]) => void;
}) => {
  const [items, setItems] = useState<Item[]>([]);
  const [current, setCurrent] = useState<Item>({ ...defaultItem });

  // Alerta pentru pondere
  const [alertMsg, setAlert] = useState<string | null>(null);

  // Adaugă criteriu cu validări
  const handleAdd = () => {
    // Validare pondere criteriu
    if (current.pondereNota > 100) {
      setAlert("Ponderea la nivel de criteriu nu poate depăși 100%!");
      return;
    }
    // Validare pondere categorie
    const totalPondereCat = items
      .filter(
        (it) =>
          it.tipIndicator === current.tipIndicator &&
          it.categorie === current.categorie
      )
      .reduce((acc, it) => acc + it.pondereCategorie, 0) + current.pondereCategorie;
    if (totalPondereCat > 100) {
      setAlert(
        `Totalul ponderii pe categoria "${current.categorie}" (${current.tipIndicator}) depășește 100%!`
      );
      return;
    }
    setAlert(null);
    setItems([...items, current]);
    setCurrent({ ...defaultItem });
  };

  // Salvează în baza de date (mock: POST la /api/formulare)
  const handleSave = async () => {
    try {
      const response = await fetch("/api/formulare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(items),
      });
      if (!response.ok) throw new Error("Eroare la salvare!");
      if (onSave) onSave(items);
      window.alert("Formular salvat cu succes!");
    } catch (e: any) {
      setAlert(e.message || "Eroare la salvare!");
    }
  };

  // Grupare criterii pe Tip Indicator și Categorie
  const grouped: Record<IndicatorType, Record<CategorieType, Item[]>> = {
    Critic: { Comunicare: [], Procedura: [], Atitudine: [] },
    "Non-Critic": { Comunicare: [], Procedura: [], Atitudine: [] },
  };
  items.forEach((item) => {
    grouped[item.tipIndicator][item.categorie].push(item);
  });

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", background: "#232323", borderRadius: 12, padding: 24 }}>
      <h2 style={{ color: "#fff", textAlign: "center" }}>Creează Formular de Evaluare</h2>
      {alertMsg && (
        <div style={{ background: "#ffdddd", color: "#b00", padding: 8, borderRadius: 6, marginBottom: 12 }}>
          {alertMsg}
        </div>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 24 }}>
        <div>
          <label style={{ color: "#fff" }}>Tip indicator:</label>
          <select value={current.tipIndicator} onChange={e => setCurrent(c => ({ ...c, tipIndicator: e.target.value as IndicatorType }))}>
            {TIPURI.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div>
          <label style={{ color: "#fff" }}>Categorie:</label>
          <select value={current.categorie} onChange={e => setCurrent(c => ({ ...c, categorie: e.target.value as CategorieType }))}>
            {CATEGORII.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label style={{ color: "#fff" }}>Descriere:</label>
          <textarea rows={3} value={current.descriere} onChange={e => setCurrent(c => ({ ...c, descriere: e.target.value }))} style={{ width: "100%" }} />
        </div>
        <div>
          <label style={{ color: "#fff" }}>Metodologie:</label>
          <textarea rows={3} value={current.metodologie} onChange={e => setCurrent(c => ({ ...c, metodologie: e.target.value }))} style={{ width: "100%" }} />
        </div>
        <div>
          <label style={{ color: "#fff" }}>Tip notă:</label>
          <select value={current.tipNota} onChange={e => setCurrent(c => ({ ...c, tipNota: e.target.value as NotaType }))}>
            <option value="1-9">1-9</option>
            <option value="1-5">1-5</option>
            <option value="0/0.5/1">0/0.5/1</option>
          </select>
        </div>
        <div>
          <label style={{ color: "#fff" }}>Pondere categorie (%):</label>
          <input type="number" value={current.pondereCategorie} onChange={e => setCurrent(c => ({ ...c, pondereCategorie: Number(e.target.value) }))} min={0} max={100} />
        </div>
        <div>
          <label style={{ color: "#fff" }}>Pondere notă (%):</label>
          <input type="number" value={current.pondereNota} onChange={e => setCurrent(c => ({ ...c, pondereNota: Number(e.target.value) }))} min={0} max={100} />
        </div>
        <div>
          <label style={{ color: "#fff" }}>Materiale de training:</label>
          <input type="text" value={current.materialeTraining} onChange={e => setCurrent(c => ({ ...c, materialeTraining: e.target.value }))} style={{ width: "100%" }} />
        </div>
        <div>
          <label style={{ color: "#fff" }}>Teme de training:</label>
          <input type="text" value={current.temeTraining} onChange={e => setCurrent(c => ({ ...c, temeTraining: e.target.value }))} style={{ width: "100%" }} />
        </div>
        <button onClick={handleAdd}>Adaugă criteriu</button>
      </div>
      {/* Tabel criterii pe Tip Indicator și Categorie */}
      <h3 style={{ color: "#fff" }}>Criterii adăugate:</h3>
      {TIPURI.map((tip) => (
        <div key={tip} style={{ marginBottom: 24 }}>
          <h4 style={{ color: "#E67E22", marginBottom: 8 }}>{tip}</h4>
          {CATEGORII.map((cat) => (
            <div key={cat} style={{ marginBottom: 12 }}>
              <div style={{ color: "#1C6B68", fontWeight: 700, marginBottom: 4 }}>{cat}</div>
              <table style={{ width: "100%", background: "#fff", borderRadius: 6, fontSize: 13, marginBottom: 4 }}>
                <thead>
                  <tr style={{ background: "#f5f5f5" }}>
                    <th>Descriere</th>
                    <th>Metodologie</th>
                    <th>Tip Notă</th>
                    <th>Pondere Cat.</th>
                    <th>Pondere Notă</th>
                    <th>Materiale Training</th>
                    <th>Teme Training</th>
                  </tr>
                </thead>
                <tbody>
                  {grouped[tip][cat].length === 0 ? (
                    <tr>
                      <td colSpan={7} style={{ textAlign: "center", color: "#888" }}>Niciun criteriu</td>
                    </tr>
                  ) : (
                    grouped[tip][cat].map((item, idx) => (
                      <tr key={idx}>
                        <td>{item.descriere}</td>
                        <td>{item.metodologie}</td>
                        <td>{item.tipNota}</td>
                        <td>{item.pondereCategorie}%</td>
                        <td>{item.pondereNota}%</td>
                        <td>{item.materialeTraining}</td>
                        <td>{item.temeTraining}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      ))}
      <div style={{ marginTop: 24 }}>
        <button onClick={onBack} style={{ marginRight: 12 }}>Înapoi</button>
        <button onClick={handleSave} disabled={items.length === 0}>Salvează formular</button>
      </div>
    </div>
  );
};

export default FormularEvaluareBuilder;