import React from "react";

const Logo = () => (
  <img
    src="/Logo/Lioran AiRT_logo only.png"
    alt="Lioran"
    style={{ height: 90, marginRight: 12 }}
  />
);

export default Logo;